const reviewModel = require('../models/review');
const addReview = async (req, res) => {
    const { userId, productId, rating, comment } = req.body;
    try {
        const review = await reviewModel.create({ userId, productId, rating, comment });
        res.status(201).json({ success: true, data: review });
    } catch (err) {
        if (err.code === 11000) return res.status(400).json({ success: false, message: "You already reviewed this product" });
        res.status(500).json({ success: false, error: err.message });
    }
};
const getProductReviews = async (req, res) => {
    try {
        const reviews = await reviewModel.find({ productId: req.params.productId }).populate('userId', 'name');
        res.status(200).json({ success: true, data: reviews });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};
const updateReview = async (req, res) => {
    const { id } = req.params;
    const { rating, comment } = req.body;
    try {
        const updatedReview = await reviewModel.findByIdAndUpdate(
            id,
            { rating, comment },
            { new: true, runValidators: true }
        );
        if (!updatedReview) {
            return res.status(404).json({ success: false, message: "Review not found" });
        }
        res.status(200).json({ success: true, message: "Review updated", data: updatedReview });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};
const deleteReview = async (req, res) => {
    const { id } = req.params;
    try {
        const deletedReview = await reviewModel.findByIdAndDelete(id);
        if (!deletedReview) {
            return res.status(404).json({ success: false, message: "Review not found" });
        }
        res.status(200).json({ success: true, message: "Review deleted successfully" });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};
module.exports = { 
    addReview, 
    getProductReviews, 
    updateReview, 
    deleteReview 
};