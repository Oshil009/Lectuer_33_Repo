const userModel = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken')
const getAllUsers = async (req, res) => {
    try {
        let { page = 1, limit = 10 } = req.query;

        page = parseInt(page);
        limit = parseInt(limit);
        const skip = (page - 1) * limit;

        const users = await userModel.find({})
            .populate('role')
            .select('-password')
            .limit(limit)
            .skip(skip);

        const totalUsers = await userModel.countDocuments({});
        const totalPages = Math.ceil(totalUsers / limit);

        if (users.length === 0) {
            return res.status(200).json({
                success: true,
                message: "No users found",
                pagination: { totalUsers: 0, totalPages: 0 },
                data: []
            });
        }

        res.status(200).json({
            success: true,
            results: users.length,
            pagination: {
                totalUsers,
                totalPages,
                currentPage: page,
                limit
            },
            data: users
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: "Server Error",
            error: err.message
        });
    }
};
const getProfile = async (req, res) => {
    try {
        const user = await userModel.findById(req.user.id)
            .populate('role')
            .populate('favorites') 
            .select('-password');
        if (!user) {
            return res.status(404).json({ success: false, message: "User not found" });
        }
        res.status(200).json({
            success: true,
            message: "User profile fetched successfully",
            data: user
        });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};
const updateProfile = async (req, res) => {
    try {
        const user = await userModel.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ success: false, message: "User not found" });
        }
        if (req.body.role) {
            delete req.body.role;
        }
        Object.assign(user, req.body);
        await user.save();
        res.status(200).json({
            success: true,
            message: "Profile updated successfully",
            data: user
        });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
};
const deleteUser = async (req, res) => {
    const { id } = req.params;
    try {
        const user = await userModel.findByIdAndDelete(id);
        if (!user) {
            return res.status(404).json({ success: false, message: "User not found" });
        }
        res.status(200).json({ success: true, message: "User deleted successfully" });
    } catch (err) {
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }
}
const toggleFavorite = async (req, res) => {
    const { productId } = req.params;
    try {
        const user = await userModel.findById(req.user.id);
        const index = user.favorites.indexOf(productId);
        if (index > -1) {
            user.favorites.splice(index, 1); 
        } else {
            user.favorites.push(productId); 
        }
        await user.save();
        res.status(200).json({
            success: true, 
            message: index > -1 ? "Removed from favorites" : "Added to favorites",
            data: user.favorites 
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
};
const createUser = async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const newUser = new userModel({
            name, email, password
        });
        const savedUser = await newUser.save();
        res.status(201).json({
            success: true,
            message: "The user has been created",
            data: savedUser
        });
    } catch (err) {
        if (err.keyPattern) {
            return res.status(409).json({
                success: false,
                message: "The email already exists"
            });
        }

        res.status(500).json({
            success: false,
            message: "Server Error",
            error: err.message
        });
    }
}
const login = async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await userModel.findOne({ email: email.toLowerCase() }).populate('role');
        if (!user) {
            return res.status(404).json("Email is not registered or Password not matched")
        }
        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) {
            return res.status(404).json("Email is not registered or Password not matched")
        }
        const payload = {
            id: user._id,
            type: user.role.role,
            permissions: user.role.permissions
        }
        const options = {
            expiresIn: "2h"
        }
        user.password=undefined;
        const userToken = await jwt.sign(payload, process.env.JWT_ACCESS_SECRET, options);
        res.status(200).json({
            success: true,
            message: "login successfully",
            token: userToken,
            data: user
        })
    } catch (err) {
        res.status(500).json({ success: false, message: "Server Error", error: err.message });
    }

}
module.exports = { getAllUsers, getProfile, updateProfile, deleteUser,toggleFavorite, createUser, login }