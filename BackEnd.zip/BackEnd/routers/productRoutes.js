const express = require("express");
const productRouter = express.Router();
const { getAllProducts, getProductById, getProductsByCategory, createProduct, updateProduct, deleteProduct } = require('../controllers/productController');
productRouter.route('/')
    .get(getAllProducts)
    .post(createProduct);
productRouter.get('/category/:categoryId', getProductsByCategory);
productRouter.route('/:id')
    .get(getProductById)
    .put(updateProduct)
    .delete(deleteProduct);

module.exports = productRouter;