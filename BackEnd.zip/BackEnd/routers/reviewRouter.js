const express = require('express');
const reviewRouter = express.Router();
const { addReview, getProductReviews, updateReview, deleteReview } = require('../controllers/reviewController');

reviewRouter.post('/', addReview);
reviewRouter.get('/product/:productId', getProductReviews);
reviewRouter.route('/:id')
    .put(updateReview)
    .delete(deleteReview);

module.exports = reviewRouter;