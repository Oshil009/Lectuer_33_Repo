const express = require('express');
const categoryRouter = express.Router();
const { getAllCategories, createCategory, updateCategory, deleteCategory } = require('../controllers/categoryController');

categoryRouter.route('/')
    .get(getAllCategories)
    .post(createCategory);

categoryRouter.route('/:id')
    .put(updateCategory)
    .delete(deleteCategory);

module.exports = categoryRouter;