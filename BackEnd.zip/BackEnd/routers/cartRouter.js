const express = require('express');
const cartRouter = express.Router();
const { addToCart, getCart, removeFromCart } = require('../controllers/cartController');

cartRouter.post('/add', addToCart);
cartRouter.get('/', getCart); 
cartRouter.post('/remove', removeFromCart);

module.exports = cartRouter;