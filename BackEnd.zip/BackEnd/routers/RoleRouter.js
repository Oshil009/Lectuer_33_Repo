const express = require("express");
const roleRouter = express.Router();
const { createRole, getAllRole, updateRole, deleteRole } = require('../controllers/RoleController');

roleRouter.route('/')
    .post(createRole)
    .get(getAllRole);

roleRouter.route('/:id')
    .put(updateRole)
    .delete(deleteRole);

module.exports = roleRouter;