const express = require('express');
const orderRouter = express.Router();
const { createOrder, getMyOrders, getOrderById, getAllOrders } = require('../controllers/orderController');

orderRouter.route('/')
    .post(createOrder)
    .get(getAllOrders);

orderRouter.get('/my', getMyOrders);

orderRouter.get('/:id', getOrderById);

module.exports = orderRouter;